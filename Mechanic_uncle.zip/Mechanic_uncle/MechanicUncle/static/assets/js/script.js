document.addEventListener("DOMContentLoaded" , function(){
    let input = "Document Is Ready"
    console.log(input);
});