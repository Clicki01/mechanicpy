from django.contrib import admin
from django.urls import path
from MechanicUncle import views

urlpatterns = [
    path('', name='ser'),
    path('Home', views.Home, name='Home'),
    # path('about', views.about, name='about'),
    # path('standard', views.standard, name='standard'),
    # path('deluxe', views.deluxe, name='deluxe'),
    # path('super', views.super, name='super'),
    # path('suite', views.suite, name='suite'),
    # path('executive', views.executive, name='executive'),
    # path('dinning', views.dinning, name='dinning'),
    # path('banquet', views.banquet, name='banquet'),
    # path('guestbook', views.guestbook, name='guestbook'),
    # path('gallery', views.gallery, name='gallery'),
    # path('contact', views.contact, name='contact'),
]
